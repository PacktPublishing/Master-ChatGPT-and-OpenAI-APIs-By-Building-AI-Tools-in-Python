import os
from dotenv import find_dotenv, load_dotenv
import openai
import streamlit as st
import json

load_dotenv(find_dotenv())

openai.api_key = os.getenv("OPENAI_API_KEY")

# DROID_ATTRIBUTES dictionary
DROID_ATTRIBUTES = {
    'appearance': 'Appearance',
    'attack': {
        'name': 'Name',
        'description': 'Description',
        'hitPoints': 0
    },
    'backstory': 'My life is great!',
    'category': 'Category',
    'description': 'Description',
    'hitPoints': 0,
    'lengthInches': 0,
    'name': 'Name',
    'power': {
        'name': 'Name',
        'description': 'Description',
        'hitPoints': 0
    },
    'resistance': 'Default',
    'retreatCost': 0,
    'type': 'Default',
    'weakness': 'Default',
    'weightPounds': 0
}



st.header("Generate a Yogi Droid 🤖")

attributes = json.dumps(DROID_ATTRIBUTES)

yogi_prompt = """Create a new kawaii droid sticker striking a Yoga 
pose with the following unique attributes:
  - Name
  - Short description less than 80 characters
  - The type of kawaii droid
  - The category of kawaii droid sticker it is
  - Number of Hit Points or health
  - The kawaii droid's length in inches
  - The kawaii droid's weight in pounds
  - The kawaii droid's power name and description
  - The kawaii droid's attack name with description and Hit Points it would cause in damage
  - The type of kawaii droid it is weak against
  - The type of kawaii droid it is resistant against
  - The retreat cost of the kawaii droid
  - The kawaii droid's appearance in less than 500 characters
  - The kawaii droid's backstory in less than 500 characters
  Format the response in the following JSON object {attributes}."""
# Generate a yogi description and attribes, generate the corresponding image 

def generate_yogi_data():
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "user", "content": yogi_prompt}
        ])
    data = response["choices"][0]["message"]["content"]
    
    return data


if st.button("Generate a Yogi Robot",
             use_container_width=True,):
    try:
        yogi_robot_data = generate_yogi_data()
        parsed_data = json.loads(yogi_robot_data)
        
        name = parsed_data["name"] if parsed_data["name"] is not None else "Default Yogi"
        description = parsed_data["description"]
        appearance = parsed_data["appearance"]
        category = parsed_data["category"]
        yogi_type = parsed_data["type"]
        yogi_power_name = parsed_data["power"]["name"]
        yogi_power_desc = parsed_data["power"]["description"]
        
        yogi_power_attack_name = parsed_data["attack"]["name"]
        yogi_power_attack_description = parsed_data["attack"]["description"]
        yogi_power_attack_damage = parsed_data["attack"]["damage"]
        backstory = parsed_data["backstory"]
        
        # Image Generation
        if parsed_data and appearance:
            response = openai.Image.create(
                prompt="""Create an image of a new kawaii droid sticker doing random Yoga pose 
        with a plain colored background that has no text or objects
        from the appearance: {appearance}""",
                n=1,
                size="1024x1024")
            
            yogi_image = response["data"][0]["url"]
            
            with st.columns(3)[1]:
                st.title(name)
                st.image(yogi_image, width=300,
                         caption=description)
                
            with st.expander("About Yogi Droid:"):
                st.write("Backstory: ", backstory)
            st.markdown("----")
            
            with st.expander("Power:"):
                st.write("Name: ", yogi_power_name)
                st.write("Description: ", yogi_power_desc)
                
            with st.expander("Attack: "):
                st.write("Name: ", yogi_power_attack_name)
                st.write("Description: ", yogi_power_attack_description)
                st.write("Damage: ", yogi_power_attack_damage)
                
        
    except json.JSONDecodeError as e:
        print("JSONDecoderError:", e)
    

