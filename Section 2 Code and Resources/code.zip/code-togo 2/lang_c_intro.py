import os
from dotenv import find_dotenv, load_dotenv
import openai
import json

import langchain 
from langchain.llms import OpenAI
from langchain.chat_models import ChatOpenAI
from langchain.agents import load_tools
from langchain.agents import initialize_agent
from langchain.agents.load_tools import get_all_tool_names
from langchain.agents import AgentType

load_dotenv(find_dotenv())
openai.api_key = os.getenv("OPENAI_API_KEY")


## ----------
# LangChain Introduction - llm and chat_model
## ------------
# llm = OpenAI()
# chat_model = ChatOpenAI()

# prompt = "How old is the earth?"
# # print(llm(prompt))
# print(chat_model.predict(prompt))
# print('\n')
# print(llm.predict(prompt))






## -----------------------------
# Prompts, templates and Chains
## -----------------------------
# llm = OpenAI(temperature=0.6)
# prompt = "Give me the best name for a Twitter Handle for an engineer"

# answer = llm(prompt)
#print(answer)

# #Next: use templates
# from langchain.prompts import PromptTemplate
# prompt_handle_template = PromptTemplate(
#     input_variables= ['profession', 'company'],
#     template="Give me the best name for a Twitter Handle for {profession} and company name {company}"
# )
# #prompt_handle_template.format(profession="Astronaut")

# #chain
# from langchain.chains import LLMChain
# chain = LLMChain(llm=llm, prompt=prompt_handle_template)
# print(chain.run({
#     'profession': 'Diver',
#     'company': 'Divers Dream'
# }))

# --------------------------------------------------------------
# Agents: Dynamically Call Chains Based on User Input
# --------------------------------------------------------------

# llm = OpenAI()
# get_all_tool_names()
# tools = load_tools(["wikipedia", "llm-math"], llm=llm)

# # Initialize an agent with the tools, the language model and type
# # of agent we want to use

# agent = initialize_agent(tools, 
#                          llm, 
#                          agent= AgentType.CHAT_ZERO_SHOT_REACT_DESCRIPTION,
#                          verbose=True)
# result = agent.run(
#     "When was Bach born and where? Multiply the year by 0.67")
# print(result)



# --------------------------------------------------------------
# Document Loaders: Load Your Own document/Data!
# --------------------------------------------------------------
from langchain.document_loaders import TextLoader
# loader = TextLoader("./test.md")
# data = loader.load()
# print(data[0].json())

# CSV
from langchain.document_loaders.csv_loader import CSVLoader
loader = CSVLoader(file_path="./test_data.csv")
data = loader.load()
print(data)







