import os
import sys
from dotenv import find_dotenv, load_dotenv
import openai

from langchain.chains import ConversationalRetrievalChain, RetrievalQA
from langchain.chat_models import ChatOpenAI
from langchain.document_loaders import DirectoryLoader, TextLoader
from langchain.embeddings import OpenAIEmbeddings
from langchain.indexes import VectorstoreIndexCreator
from langchain.indexes.vectorstore import VectorStoreIndexWrapper
from langchain.llms import OpenAI
from langchain.vectorstores import Chroma


load_dotenv(find_dotenv())
openai.api_key = os.getenv("OPENAI_API_KEY")

PERSIST = False

query = None
if len(sys.argv) > 1:
    query = sys.argv[1]
    
if PERSIST and os.path.exists("persist"):
    vectorStore = Chroma(persist_directory="persist",
                         embedding_function=OpenAIEmbeddings())
else:
    loader = DirectoryLoader("data/")
    if PERSIST:
        index = VectorstoreIndexCreator(vectorstore_kwargs={
            "persist_directory": "persist"
        }).from_loaders([loader])
    else:
        index = VectorstoreIndexCreator().from_loaders([loader])
        
        
# set up the Conversational Retriever Chain
chain = ConversationalRetrievalChain.from_llm(
  llm=ChatOpenAI(model="gpt-3.5-turbo"),
  retriever=index.vectorstore.as_retriever(search_kwargs={"k": 1})
)

chat_history = []
while True:
    if not query:
        query = input("Prompt: ")
    if query in ['quit', 'q', 'exit']:
        sys.exit()
    result = chain({"question": query, "chat_history": chat_history})
    print(result["answer"])
    
    chat_history.append((query, result["answer"]))
    query = None  
    
      
     
